import { motion, useInView, useScroll, useTransform } from "framer-motion";
import { useRef, useState } from "react";
import { ExternalLink, Code, Palette, Layout } from "lucide-react";

interface Project {
  title: string;
  category: string;
  description: string;
  tools: string[];
  learnings: string[];
  icon: any;
  color: string;
}

const Projects = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"]
  });
  const y = useTransform(scrollYProgress, [0, 1], [100, -100]);
  const rotate = useTransform(scrollYProgress, [0, 1], [0, 360]);
  const scale = useTransform(scrollYProgress, [0, 0.5, 1], [0.8, 1, 0.8]);
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

  const projects: Project[] = [
    {
      title: "Brand Identity Design",
      category: "Logo Design",
      description: "Created modern logo concepts exploring color theory, typography, and visual balance.",
      tools: ["Figma", "Adobe Illustrator", "Canva"],
      learnings: ["Color psychology", "Typography pairing", "Brand consistency"],
      icon: Palette,
      color: "from-red-500/20 to-orange-500/20",
    },
    {
      title: "UI Mockup Collection",
      category: "UI/UX Design",
      description: "Designed responsive web interfaces focusing on user experience and modern aesthetics.",
      tools: ["Figma", "Adobe XD"],
      learnings: ["Visual hierarchy", "Responsive design", "User flow mapping"],
      icon: Layout,
      color: "from-primary/20 to-pink-500/20",
    },
    {
      title: "Web Development Practice",
      category: "Frontend",
      description: "Built interactive web pages using HTML, CSS, and JavaScript with focus on clean code.",
      tools: ["HTML", "CSS", "JavaScript", "React"],
      learnings: ["DOM manipulation", "CSS animations", "Component architecture"],
      icon: Code,
      color: "from-blue-500/20 to-primary/20",
    },
    {
      title: "Poster Design Series",
      category: "Graphic Design",
      description: "Experimented with layout composition, typography, and visual storytelling for events.",
      tools: ["Canva", "Figma", "Photoshop"],
      learnings: ["Layout design", "Typography hierarchy", "Visual impact"],
      icon: Palette,
      color: "from-purple-500/20 to-primary/20",
    },
  ];

  return (
    <section id="projects" ref={ref} className="py-24 px-6 relative overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-background to-card/20" />
      
      {/* Animated background shapes */}
      <motion.div
        style={{ y, rotate }}
        className="absolute -top-20 -right-20 w-96 h-96 border-2 border-primary/10 rounded-full"
      />
      <motion.div
        style={{ scale }}
        className="absolute bottom-20 left-20 w-72 h-72 bg-primary/5 rounded-lg blur-[80px]"
      />
      <motion.div
        animate={{ 
          x: [0, 100, 0],
          y: [0, -50, 0],
          opacity: [0.3, 0.6, 0.3]
        }}
        transition={{ duration: 15, repeat: Infinity, ease: "easeInOut" }}
        className="absolute top-1/2 right-1/4 w-2 h-2 bg-primary rounded-full blur-sm"
      />
      <motion.div
        animate={{ 
          x: [0, -80, 0],
          y: [0, 60, 0],
          opacity: [0.2, 0.5, 0.2]
        }}
        transition={{ duration: 12, repeat: Infinity, ease: "easeInOut", delay: 2 }}
        className="absolute bottom-1/3 left-1/3 w-3 h-3 bg-primary/70 rounded-full blur-sm"
      />
      
      <div className="container mx-auto relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="font-display text-4xl lg:text-6xl font-bold mb-4 overflow-hidden">
            <motion.span
              initial={{ opacity: 0, y: 60, rotateX: -90 }}
              animate={isInView ? { opacity: 1, y: 0, rotateX: 0 } : {}}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="inline-block"
              style={{ transformOrigin: "bottom" }}
            >
              Featured{" "}
            </motion.span>
            <motion.span 
              className="text-primary text-glow inline-block"
              initial={{ opacity: 0, y: 60, rotateX: -90 }}
              animate={isInView ? { opacity: 1, y: 0, rotateX: 0 } : {}}
              transition={{ duration: 0.8, delay: 0.4 }}
              style={{ transformOrigin: "bottom" }}
            >
              Projects
            </motion.span>
          </h2>
          <motion.p 
            className="text-muted-foreground text-lg max-w-2xl mx-auto"
            initial={{ opacity: 0 }}
            animate={isInView ? { opacity: 1 } : {}}
            transition={{ duration: 1, delay: 0.8 }}
          >
            Practice projects showcasing my learning journey and creative exploration
          </motion.p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-6 max-w-6xl mx-auto">
          {projects.map((project, index) => (
            <motion.div
              key={project.title}
              initial={{ opacity: 0, y: 40 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              onHoverStart={() => setHoveredIndex(index)}
              onHoverEnd={() => setHoveredIndex(null)}
              className="group relative"
            >
              <motion.div 
                className="bg-card border border-border rounded-2xl p-8 h-full"
                whileHover={{ 
                  y: -10,
                  boxShadow: "0 20px 60px rgba(255, 45, 45, 0.4)",
                  borderColor: "rgba(255, 45, 45, 0.6)"
                }}
                transition={{ duration: 0.3 }}
              >
                {/* Gradient overlay */}
                <div className={`absolute inset-0 bg-gradient-to-br ${project.color} rounded-2xl opacity-0 group-hover:opacity-100 transition-smooth -z-10`} />
                
                <div className="space-y-6">
                  {/* Header */}
                  <div className="flex items-start justify-between">
                    <motion.div 
                      className="bg-primary/10 p-3 rounded-xl group-hover:bg-primary/20 transition-smooth"
                      whileHover={{ scale: 1.1, rotate: 5 }}
                    >
                      <project.icon className="h-6 w-6 text-primary" />
                    </motion.div>
                    <motion.span 
                      className="text-xs text-muted-foreground font-display uppercase tracking-wider"
                      whileHover={{ scale: 1.1, color: "hsl(0 100% 59%)" }}
                    >
                      {project.category}
                    </motion.span>
                  </div>

                  {/* Content */}
                  <div className="space-y-3">
                    <motion.h3 
                      className="font-display text-2xl font-bold group-hover:text-primary transition-smooth"
                      whileHover={{ x: 5 }}
                    >
                      {project.title}
                    </motion.h3>
                    <motion.p 
                      className="text-muted-foreground leading-relaxed"
                      whileHover={{ x: 3 }}
                    >
                      {project.description}
                    </motion.p>
                  </div>

                  {/* Tools */}
                  <div className="space-y-2">
                    <p className="text-sm font-display font-semibold text-primary">Tools Used</p>
                    <div className="flex flex-wrap gap-2">
                      {project.tools.map((tool) => (
                        <motion.span
                          key={tool}
                          className="px-3 py-1 bg-secondary border border-border rounded-full text-xs text-muted-foreground group-hover:border-primary/30 transition-smooth cursor-pointer"
                          whileHover={{ 
                            scale: 1.1, 
                            y: -2,
                            borderColor: "rgba(255, 45, 45, 0.5)",
                            color: "hsl(0 100% 59%)",
                            boxShadow: "0 5px 15px rgba(255, 45, 45, 0.3)"
                          }}
                        >
                          {tool}
                        </motion.span>
                      ))}
                    </div>
                  </div>

                  {/* Learnings */}
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={
                      hoveredIndex === index
                        ? { height: "auto", opacity: 1 }
                        : { height: 0, opacity: 0 }
                    }
                    transition={{ duration: 0.3 }}
                    className="overflow-hidden space-y-2"
                  >
                    <p className="text-sm font-display font-semibold text-primary">What I Learned</p>
                    <ul className="space-y-1">
                      {project.learnings.map((learning) => (
                        <li key={learning} className="text-sm text-muted-foreground flex items-center gap-2">
                          <div className="w-1.5 h-1.5 bg-primary rounded-full" />
                          {learning}
                        </li>
                      ))}
                    </ul>
                  </motion.div>
                </div>
              </motion.div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Projects;
