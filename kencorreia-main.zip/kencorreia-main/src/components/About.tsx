import { motion, useInView, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";
import { GraduationCap, Code, Palette, Target } from "lucide-react";

const About = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"]
  });
  const y = useTransform(scrollYProgress, [0, 1], [100, -100]);
  const rotate = useTransform(scrollYProgress, [0, 1], [0, 360]);
  const opacity = useTransform(scrollYProgress, [0, 0.3, 0.7, 1], [0.3, 1, 1, 0.3]);
  const scale = useTransform(scrollYProgress, [0, 0.5, 1], [0.8, 1, 0.8]);

  const education = {
    degree: "B.Tech / B.E. in Computer Engineering",
    status: "Pursuing",
    college: "Fr. Conceicao Rodrigues College of Engineering",
    graduation: "2029",
    coursework: ["Web Basics", "C/Python Programming", "UI/UX Foundations", "Prototyping"],
  };

  return (
    <section ref={ref} className="py-24 px-6 relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0 bg-gradient-to-b from-background to-card/20" />
      <motion.div
        style={{ y, opacity, scale }}
        className="absolute top-1/4 right-1/4 w-96 h-96 bg-primary/10 rounded-full blur-[120px]"
      />
      <motion.div
        style={{ rotate, opacity }}
        className="absolute bottom-1/4 left-1/4 w-64 h-64 border border-primary/10 rounded-full"
      />
      {[...Array(8)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-2 h-2 bg-primary/40 rounded-full"
          style={{
            left: `${20 + i * 10}%`,
            top: `${30 + (i % 3) * 20}%`,
          }}
          animate={{
            y: [0, -50, 0],
            opacity: [0.2, 0.8, 0.2],
            scale: [1, 1.5, 1],
          }}
          transition={{
            duration: 3 + i * 0.5,
            repeat: Infinity,
            delay: i * 0.3,
          }}
        />
      ))}
      
      <div className="container mx-auto relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="font-display text-4xl lg:text-6xl font-bold mb-4 overflow-hidden">
            <motion.span
              initial={{ opacity: 0, y: 50 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="inline-block"
            >
              About{" "}
            </motion.span>
            <motion.span 
              className="text-primary text-glow inline-block"
              initial={{ opacity: 0, y: 50, scale: 0.8 }}
              animate={isInView ? { opacity: 1, y: 0, scale: 1 } : {}}
              transition={{ duration: 0.6, delay: 0.4 }}
            >
              Me
            </motion.span>
          </h2>
          <motion.div 
            className="w-24 h-1 bg-primary mx-auto"
            initial={{ width: 0 }}
            animate={isInView ? { width: 96 } : {}}
            transition={{ duration: 0.8, delay: 0.6 }}
          />
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12 items-start max-w-6xl mx-auto">
          {/* Bio */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="space-y-6"
          >
            <div className="prose prose-invert max-w-none">
              <motion.p 
                className="text-lg text-muted-foreground leading-relaxed"
                whileHover={{ x: 5, color: "hsl(0 100% 59%)" }}
                transition={{ duration: 0.3 }}
              >
                I'm Ken Correia, a creative student exploring design, technology, and digital innovation. 
                I enjoy turning ideas into clean, user-friendly experiences.
              </motion.p>
              <motion.p 
                className="text-lg text-muted-foreground leading-relaxed"
                whileHover={{ x: 5, color: "hsl(0 100% 59%)" }}
                transition={{ duration: 0.3 }}
              >
                I'm currently building my skills and working on projects that reflect my growth and passion. 
                Every project is a learning opportunity, and I'm excited about the journey ahead.
              </motion.p>
            </div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.4 }}
              whileHover={{ scale: 1.02, boxShadow: "0 0 60px rgba(255, 45, 45, 0.5)", borderColor: "rgba(255, 45, 45, 0.6)" }}
              className="bg-card border border-primary/20 rounded-lg p-6 box-glow cursor-pointer"
            >
              <div className="flex items-center gap-3 mb-4">
                <Target className="h-6 w-6 text-primary" />
                <h3 className="font-display text-xl font-semibold">Current Goals</h3>
              </div>
              <p className="text-muted-foreground">
                Looking for internships & real-world project opportunities to apply my skills 
                and grow as a developer and designer.
              </p>
            </motion.div>
          </motion.div>

          {/* Education Card */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="relative"
          >
            <motion.div 
              className="bg-gradient-to-br from-card to-card/50 border border-primary/20 rounded-2xl p-8 space-y-6 box-glow"
              whileHover={{ scale: 1.02, borderColor: "rgba(255, 45, 45, 0.5)" }}
              transition={{ duration: 0.3 }}
            >
              <div className="flex items-start justify-between">
                <div className="bg-primary/10 p-3 rounded-xl">
                  <GraduationCap className="h-8 w-8 text-primary" />
                </div>
                <span className="px-4 py-1 bg-primary/20 text-primary text-sm font-display rounded-full">
                  {education.status}
                </span>
              </div>

              <div className="space-y-3">
                <h3 className="font-display text-2xl font-bold">{education.degree}</h3>
                <p className="text-muted-foreground">{education.college}</p>
                <p className="text-sm text-primary font-display">Expected Graduation: {education.graduation}</p>
              </div>

              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <Code className="h-5 w-5 text-primary" />
                  <h4 className="font-display font-semibold">Coursework</h4>
                </div>
                <div className="flex flex-wrap gap-2">
                  {education.coursework.map((course, index) => (
                    <motion.span
                      key={course}
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={isInView ? { opacity: 1, scale: 1 } : {}}
                      transition={{ duration: 0.4, delay: 0.5 + index * 0.1 }}
                      whileHover={{ scale: 1.1, y: -2, boxShadow: "0 5px 15px rgba(255, 45, 45, 0.3)" }}
                      className="px-3 py-1 bg-secondary border border-border rounded-full text-sm text-muted-foreground hover:text-primary hover:border-primary transition-smooth cursor-pointer"
                    >
                      {course}
                    </motion.span>
                  ))}
                </div>
              </div>

              <div className="pt-4 border-t border-border">
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Palette className="h-5 w-5" />
                  <p className="text-sm">
                    Passionate about blending creativity with technical skills
                  </p>
                </div>
              </div>
            </motion.div>

            {/* Decorative elements */}
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 25, repeat: Infinity, ease: "linear" }}
              whileHover={{ scale: 1.3, borderColor: "rgba(255, 45, 45, 0.7)" }}
              className="absolute -top-4 -right-4 w-20 h-20 border border-primary/30 rounded-full cursor-pointer"
            />
            <motion.div
              animate={{ rotate: -360, scale: [1, 1.2, 1] }}
              transition={{ duration: 18, repeat: Infinity, ease: "linear" }}
              whileHover={{ scale: 1.5, borderColor: "rgba(255, 45, 45, 0.6)" }}
              className="absolute -bottom-6 -left-6 w-16 h-16 border-2 border-primary/20 rounded-lg cursor-pointer"
            />
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default About;
