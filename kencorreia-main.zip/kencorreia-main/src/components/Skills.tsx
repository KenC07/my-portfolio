import { motion, useInView, useScroll, useTransform } from "framer-motion";
import { useRef, useEffect, useState } from "react";

interface Skill {
  name: string;
  level: number;
  category: string;
}

const Skills = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"]
  });
  const opacity = useTransform(scrollYProgress, [0, 0.5, 1], [0.3, 1, 0.3]);
  const scale = useTransform(scrollYProgress, [0, 0.5, 1], [0.95, 1, 0.95]);
  const rotate = useTransform(scrollYProgress, [0, 1], [0, 360]);

  const skills: Skill[] = [
    { name: "HTML & CSS", level: 70, category: "Frontend" },
    { name: "JavaScript", level: 45, category: "Frontend" },
    { name: "Python", level: 55, category: "Backend" },
    { name: "C Programming", level: 50, category: "Backend" },
    { name: "UI/UX Design", level: 60, category: "Design" },
    { name: "Figma Prototyping", level: 65, category: "Design" },
    { name: "Logo Design", level: 55, category: "Design" },
    { name: "Poster Design", level: 60, category: "Design" },
  ];

  return (
    <section id="skills" ref={ref} className="py-24 px-6 relative overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-card/20 to-background" />
      
      {/* Animated background elements */}
      <motion.div
        style={{ opacity, scale }}
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-primary/5 rounded-full blur-[100px]"
      />
      <motion.div
        style={{ rotate }}
        className="absolute top-20 right-20 w-32 h-32 border border-primary/20 rounded-lg"
      />
      <motion.div
        animate={{ 
          x: [-20, 20, -20],
          y: [-20, 20, -20]
        }}
        transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
        className="absolute bottom-20 left-20 w-4 h-4 bg-primary/50 rounded-full blur-sm"
      />
      
      <div className="container mx-auto relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="font-display text-4xl lg:text-6xl font-bold mb-4 overflow-hidden">
            <motion.span
              initial={{ opacity: 0, x: -30 }}
              animate={isInView ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="inline-block"
            >
              My{" "}
            </motion.span>
            <motion.span 
              className="text-primary text-glow inline-block"
              initial={{ opacity: 0, scale: 0.5, rotate: -10 }}
              animate={isInView ? { opacity: 1, scale: 1, rotate: 0 } : {}}
              transition={{ duration: 0.8, delay: 0.4 }}
            >
              Skills
            </motion.span>
          </h2>
          <motion.p 
            className="text-muted-foreground text-lg max-w-2xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.6 }}
          >
            Building proficiency across design and development
          </motion.p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {skills.map((skill, index) => (
            <SkillBar key={skill.name} skill={skill} index={index} isInView={isInView} />
          ))}
        </div>
      </div>
    </section>
  );
};

const SkillBar = ({ skill, index, isInView }: { skill: Skill; index: number; isInView: boolean }) => {
  const [count, setCount] = useState(0);

  useEffect(() => {
    if (isInView) {
      const duration = 1500;
      const steps = 60;
      const increment = skill.level / steps;
      let current = 0;

      const timer = setInterval(() => {
        current += increment;
        if (current >= skill.level) {
          setCount(skill.level);
          clearInterval(timer);
        } else {
          setCount(Math.floor(current));
        }
      }, duration / steps);

      return () => clearInterval(timer);
    }
  }, [isInView, skill.level]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={isInView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      className="group"
    >
      <motion.div 
        className="bg-card border border-border rounded-xl p-6 hover:border-primary/50 transition-smooth hover:box-glow"
        whileHover={{ 
          scale: 1.03, 
          y: -5,
          boxShadow: "0 10px 40px rgba(255, 45, 45, 0.4)",
          borderColor: "rgba(255, 45, 45, 0.6)"
        }}
        transition={{ duration: 0.3 }}
      >
        <div className="flex justify-between items-center mb-3">
          <div>
            <h3 className="font-display font-semibold text-lg">{skill.name}</h3>
            <p className="text-xs text-muted-foreground">{skill.category}</p>
          </div>
          <motion.span
            className="text-2xl font-display font-bold text-primary"
            initial={{ opacity: 0 }}
            animate={isInView ? { opacity: 1 } : {}}
            transition={{ duration: 0.3, delay: index * 0.1 + 0.5 }}
          >
            {count}%
          </motion.span>
        </div>

        <div className="relative h-3 bg-secondary rounded-full overflow-hidden">
          <motion.div
            initial={{ width: 0 }}
            animate={isInView ? { width: `${skill.level}%` } : {}}
            transition={{ duration: 1.5, delay: index * 0.1, ease: "easeOut" }}
            className="absolute inset-y-0 left-0 bg-gradient-to-r from-primary to-primary/70 rounded-full"
          />
          <motion.div
            animate={{
              x: ["0%", "100%", "0%"],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: "linear",
            }}
            className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent"
            style={{ width: "50%" }}
          />
        </div>
      </motion.div>
    </motion.div>
  );
};

export default Skills;
