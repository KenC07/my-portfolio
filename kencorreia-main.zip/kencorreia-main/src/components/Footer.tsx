import { motion } from "framer-motion";
import { Instagram, Linkedin, Mail, Github } from "lucide-react";

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="relative py-16 px-6 overflow-hidden">
      {/* Large background text */}
      <div className="absolute inset-0 flex items-center justify-center opacity-5 pointer-events-none">
        <p className="font-display text-[20vw] font-bold">KC</p>
      </div>

      <div className="container mx-auto relative z-10">
        <div className="flex flex-col items-center text-center space-y-8">
          {/* Logo/Name */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h3 className="font-display text-3xl font-bold">
              KEN <span className="text-primary">CORREIA</span>
            </h3>
            <p className="text-muted-foreground mt-2">Creative Student & Aspiring Engineer</p>
          </motion.div>

          {/* Social Links */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            viewport={{ once: true }}
            className="flex gap-4"
          >
            <a
              href="https://www.instagram.com/ken_correia_"
              target="_blank"
              rel="noopener noreferrer"
              className="p-3 bg-card border border-border rounded-lg hover:border-primary hover:bg-primary/10 transition-smooth group"
            >
              <Instagram className="h-5 w-5 text-muted-foreground group-hover:text-primary transition-smooth" />
            </a>
            <a
              href="https://www.linkedin.com/in/ken-correia-b27676392"
              target="_blank"
              rel="noopener noreferrer"
              className="p-3 bg-card border border-border rounded-lg hover:border-primary hover:bg-primary/10 transition-smooth group"
            >
              <Linkedin className="h-5 w-5 text-muted-foreground group-hover:text-primary transition-smooth" />
            </a>
            <a
              href="mailto:kenfebian@gmail.com"
              className="p-3 bg-card border border-border rounded-lg hover:border-primary hover:bg-primary/10 transition-smooth group"
            >
              <Mail className="h-5 w-5 text-muted-foreground group-hover:text-primary transition-smooth" />
            </a>
          </motion.div>

          {/* Quick Links */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            viewport={{ once: true }}
            className="flex flex-wrap gap-6 text-sm text-muted-foreground"
          >
            <button
              onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
              className="hover:text-primary transition-smooth"
            >
              Home
            </button>
            <button
              onClick={() => document.getElementById("projects")?.scrollIntoView({ behavior: "smooth" })}
              className="hover:text-primary transition-smooth"
            >
              Projects
            </button>
            <button
              onClick={() => document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" })}
              className="hover:text-primary transition-smooth"
            >
              Contact
            </button>
          </motion.div>

          {/* Copyright */}
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            viewport={{ once: true }}
            className="pt-8 border-t border-border w-full"
          >
            <p className="text-sm text-muted-foreground">
              © {currentYear} Ken Correia. All rights reserved.
            </p>
            <p className="text-xs text-muted-foreground mt-2">
              Computer Engineering Student • Fr. CRCE • Class of 2029
            </p>
          </motion.div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
